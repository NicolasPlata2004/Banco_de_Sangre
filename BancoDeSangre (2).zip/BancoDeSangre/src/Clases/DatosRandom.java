package Clases;

import java.util.Random;

public class DatosRandom {

        private static final String[] NOMBRES = {"Juan", "María", "Luis", "Ana", "Carlos", "Elena"};
        private static final String[] APELLIDOS = {"Gómez", "Pérez", "Rodríguez", "Fernández", "López", "Martínez"};
        private static final String[] CORREOS = {"gmail.com", "yahoo.com", "hotmail.com"};

        public static Paciente generarPacienteAleatorio() {
            Random random = new Random();

            String nombreAleatorio = generarNombreAleatorio();
            String documentoAleatorio = String.valueOf(random.nextInt(1000000) + 100000); // Número aleatorio de 6 dígitos.
            String celularAleatorio = "+1-" + (random.nextInt(900) + 100) + "-" + (random.nextInt(900) + 100) + "-" + (random.nextInt(9000) + 1000);
            String correoAleatorio = generarCorreoAleatorio();
            String tipoSangreAleatorio = generarTipoSangreAleatorio();
            int edadAleatoria = random.nextInt(60) + 18; // Edad entre 18 y 77.
            int prioridadAleatoria = random.nextInt(3) + 1; // Prioridad entre 1 y 3.

            return new Paciente(nombreAleatorio, documentoAleatorio, celularAleatorio, correoAleatorio, tipoSangreAleatorio, edadAleatoria, prioridadAleatoria);
        }

        private static String generarNombreAleatorio() {
            Random random = new Random();
            String nombre = NOMBRES[random.nextInt(NOMBRES.length)];
            String apellido = APELLIDOS[random.nextInt(APELLIDOS.length)];
            return nombre + " " + apellido;
        }

        private static String generarCorreoAleatorio() {
            Random random = new Random();
            String nombre = generarNombreAleatorio().toLowerCase().replace(" ", ".");
            String dominio = CORREOS[random.nextInt(CORREOS.length)];
            return nombre + "@" + dominio;
        }

        private static String generarTipoSangreAleatorio() {
            String[] tiposSangre = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"};
            Random random = new Random();
            return tiposSangre[random.nextInt(tiposSangre.length)];
        }
    }




