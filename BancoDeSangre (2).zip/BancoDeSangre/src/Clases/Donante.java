    package Clases;
    import util.*;
    public class Donante {

        public String nombreD;
        public String documentoD;
        public String celularD;
        public String correoD;
        public String tipoSangreD;
        public  int edadD;

        public Donante(String nombreD, String documentoD, String celularD, String correoD, String tipoSangreD, int edad) {

            this.nombreD = nombreD;
            this.documentoD = documentoD;
            this.celularD = celularD;
            this.correoD = correoD;
            this.tipoSangreD = tipoSangreD;
            this.edadD = edad;
        }
        @Override
        public String toString() {
            return nombreD + "," + documentoD + "," + celularD + "," + correoD + "," + tipoSangreD + "," + edadD;

        }
        public void setNombre(String nuevoNombre) {
            this.nombreD = nuevoNombre;
        }


        public void setDocumento(String nuevoDocumento) {
            this.documentoD = nuevoDocumento;
        }

        public void setNombreP(String nombreD) {
            this.nombreD = nombreD;
        }

        public void setDocumentoD(String documentoD) {
            this.documentoD = documentoD;
        }

        public void setCelularD(String celularD) {
            this.celularD = celularD;
        }

        public void setCorreoD(String correoD) {
            this.correoD = correoD;
        }

        public void setTipoDeSangreD(String tipoDeSangreD) {
            this.tipoSangreD = tipoDeSangreD;
        }

        public void setEdadD(int edadD) {
            this.edadD = edadD;
        }
        public String getNombre() {
            return nombreD;
        }

        public String getDocumento() {
            return documentoD;
        }

        public String getCelular() {
            return celularD;
        }

        public String getCorreo() {
            return correoD;
        }

        public String getTipoSangre() {
            return tipoSangreD;
        }

        public int getEdad() {
            return edadD;
        }

    }

