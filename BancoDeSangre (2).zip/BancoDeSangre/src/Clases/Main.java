package Clases;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import Menus.*;
import javafx.scene.control.*;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.collections.*;
import javafx.geometry.*;

public class Main extends Application {
    private DonantesMenu donantesMenu;
    private PacientesMenu pacientesMenu;

    @Override
    public void start(Stage primaryStage) {

        // Crear el encabezado con el nombre del banco y la imagen
        HBox header = createHeader(primaryStage);

        HBox blocksContainerPersonas = new HBox(100);  // Espaciado entre los bloques
        blocksContainerPersonas.getStyleClass().add("blocks-container");
        blocksContainerPersonas.setAlignment(Pos.CENTER);

        Image banner = new Image(getClass().getResource("/imagenes/baner.png").toExternalForm());
        ImageView imageView2 = new ImageView(banner);
        imageView2.setFitWidth(1150); // Ajusta el ancho según tus necesidades
        imageView2.setFitHeight(300); // Ajusta la altura según tus necesidades



        // Primer bloque
        StackPane block1 = createBlock("Tu Donación de Sangre Salva Vidas como la de Sofía\n" +
                        "Querido amigo, Cada gota de sangre que donas es una chispa de esperanza. Gracias a personas como tú, Sofía" +
                        " superó una enfermedad y ahora juega felizmente con su hermana Marta. Tu donación crea estos momentos.", "Imagen 1",
                         "Sofia.jpg");
        // Segundo bloque
        StackPane block2 = createBlock("Tu Donación de Sangre Salvó a José\n" +
                "Querido amigo, José sobrevivió a un grave accidente gracias a donaciones " +
                "de sangre como la tuya. Ahora disfruta de su familia. Tu generosidad marca " +
                "la diferencia.", "Imagen 2", "inicio.jpg");
        // Tercer bloque
        StackPane block3 = createBlock("Tu Donación de Sangre Cambió Vidas Como la de Roberto\n" +
                "Querido amigo, Un infarto puso en peligro la vida de este anciano, pero gracias a donaciones" +
                " de sangre como la tuya, pudo superarlo. Ahora, junto a su esposa Josefina, fundaron un orfanato. " +
                "Tu generosidad hace posible estas historias de amor y esperanza.", "Imagen 3",
                "inicio.jpg");

        blocksContainerPersonas.getChildren().addAll(block1, block2, block3);

        // Agregar el contenedor de bloques y el cuarto bloque al contenedor principal
        HBox blockContainerConocenos = new HBox(10);
        blockContainerConocenos.getStyleClass().add("blocks-container-conocenos");
        blockContainerConocenos.setAlignment(Pos.CENTER);


        // Agregar el cuarto bloque con otra imagen
        StackPane block4 = createBlockConocenos("Acerca de nosotros\n" +
                "¡Bienvenido a nuestra página web! Nuestros nombres son Juan Manuel Beltran," +
                " Oscar Jhondairo, Nicolas Plata estudiantes de Ingeniería Mecatrónica." +
                " Nuestro objetivo con esta pagina web es facilitar un poco la magnifica labor de " +
                "todos aquellos donantes de sangre y ayudar a todos aquellos pacientes que en circustancias" +
                " de vida o muerte necesitan que esto sea mas rapido.", "Imagen 4", "inicio.jpg");

        blockContainerConocenos.getChildren().addAll(block4);


        // Layout para la interfaz de inicio
        VBox loginLayout = new VBox(10);
        loginLayout.getStyleClass().add("login-container");
        loginLayout.setAlignment(Pos.CENTER);
        loginLayout.getChildren().addAll( blocksContainerPersonas, blockContainerConocenos, imageView2);



        // Crear un VBox para organizar el encabezado y la interfaz de inicio
        VBox mainLayout = new VBox();
        mainLayout.getChildren().addAll(header, loginLayout);



        // Configurar el contenido del ScrollPane
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(loginLayout);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);

        // Crear el StackPane principal y agregar el VBox que contiene el encabezado y la interfaz de inicio
        StackPane root = new StackPane();
        root.getChildren().addAll(mainLayout);


        // Agregar el ScrollPane al layout principal
        mainLayout.getChildren().add(scrollPane);

        Scene scene = new Scene(root, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/Menus/Main.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.setTitle("Bienvenido al Banco de Sangre");
        primaryStage.show();
    }


    private StackPane createBlock(String labelText, String imageName, String imagePath) {
        StackPane block = new StackPane();

        // Configura la imagen
        Image image = new Image(getClass().getResource("/imagenes/" + imagePath).toExternalForm());
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(250);  // Ajusta el ancho según tus necesidades
        imageView.setFitHeight(250); // Ajusta la altura según tus necesidades
        imageView.setStyle("-fx-border-radius: 10;");
        imageView.getStyleClass().add("image-Personas");

        // Configura el texto
        Label label = new Label(labelText);
        label.setMaxWidth(imageView.getFitWidth());
        label.setPrefHeight(Region.USE_COMPUTED_SIZE);    // Ajusta la altura máxima para mostrar
        label.setWrapText(true);


        // Crea un VBox para apilar verticalmente la imagen y el texto
        VBox vBox = new VBox();
        vBox.getChildren().addAll(imageView, label);
        vBox.setAlignment(Pos.CENTER);  // Ajusta la alineación del VBox
        vBox.getStyleClass().add("stack-panePersonas");  // Añade la clase de estilo al VBox
        imageView.setStyle("-fx-border-radius: 10;");


        block.getChildren().add(vBox);
        return block;
    }
    private StackPane createBlockConocenos(String labelText, String imageName, String imagePath) {
        StackPane block = new StackPane();

        // Configura la imagen
        Image image = new Image(getClass().getResource("/imagenes/" + imagePath).toExternalForm());
        ImageView imageView1 = new ImageView(image);
        imageView1.setFitWidth(200);  // Ajusta el ancho según tus necesidades
        imageView1.setFitHeight(200); // Ajusta la altura según tus necesidades
        imageView1.getStyleClass().add("image-conocenos");

        // Configura el texto
        Label label = new Label(labelText);
        label.setMaxWidth(600);
        label.setMaxHeight(Double.MAX_VALUE);  // Ajusta la altura máxima para mostrar todo el texto
        label.setWrapText(true);


        // Crea un VBox para apilar verticalmente la imagen y el texto
        VBox vBox = new VBox();
        vBox.getChildren().addAll(imageView1, label);
        vBox.setAlignment(Pos.CENTER);  // Ajusta la alineación del VBox
        vBox.getStyleClass().add("stack-paneConocenos");  // Añade la clase de estilo al VBox



        block.getChildren().add(vBox);
        return block;
    }

    private HBox createHeader(Stage primaryStage) {
        HBox header = new HBox(700); // Espaciado entre elementos del encabezado
        header.getStyleClass().add("header");

        HBox leftHeaderSection = new HBox(10);
        leftHeaderSection.setAlignment(Pos.CENTER_LEFT);


        HBox rightHeaderSection = new HBox(10);
        rightHeaderSection.setAlignment(Pos.CENTER_RIGHT);

        // Intenta cargar la imagen directamente desde el sistema de archivos
        Image logoImage = new Image("imagenes/gota de sangre.jpg");
        ImageView logoImageView = new ImageView(logoImage);
        logoImageView.setFitWidth(50); // Ajustar el ancho según tus necesidades
        logoImageView.setFitHeight(50); // Ajustar la altura según tus necesidades

        // Configurar el nombre del banco
        Label bankNameLabel = new Label("Banco de Sangre"); // Cambiar el nombre según tus necesidades
        bankNameLabel.getStyleClass().add("bank-name");

        // Agregar la imagen y el nombre al encabezado
        leftHeaderSection.getChildren().addAll(logoImageView, bankNameLabel);


        // ChoiceBox para seleccionar el tipo de usuario
        ChoiceBox<String> userTypeChoice = new ChoiceBox<>(FXCollections.observableArrayList("Operador", "Otro"));
        userTypeChoice.setValue("Operador");  // Valor predeterminado


        Button loginButton = new Button("Iniciar Sesión");
        loginButton.getStyleClass().add("login-button");
        loginButton.setOnAction(e -> mostrarInterfazSegunUsuario(primaryStage, userTypeChoice.getValue()));
        rightHeaderSection.getChildren().addAll(userTypeChoice, loginButton);

        header.getChildren().addAll(leftHeaderSection, rightHeaderSection);
        header.setAlignment(Pos.CENTER);
        return header;


    }


    private void mostrarInterfazSegunUsuario(Stage primaryStage, String tipoUsuario) {
        if ("operador".equalsIgnoreCase(tipoUsuario)) {
            mostrarMenuOperador(primaryStage);
        } else {
            // Lógica para otros tipos de usuario
            // Puedes tener más botones, campos de texto, etc., según tus necesidades
        }
    }
    private void mostrarMenuOperador(Stage primaryStage) {
        MenuOperador menuOperador = new MenuOperador();
        menuOperador.start(primaryStage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}