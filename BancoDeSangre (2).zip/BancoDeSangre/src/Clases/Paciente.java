package Clases;
import util.*;
public class Paciente{

    public String nombreP;
    public String documentoP;
    public String celularP;
    public String correoP;
    public String tipoDeSangreP;
    public int edadD;
    public int prioridad;

    public Paciente(String nombreP, String documentoP, String celularP, String correoP, String tipoDeSangreP, int edadD, int prioridad) {

        this.nombreP = nombreP;
        this.documentoP = documentoP;
        this.celularP = celularP;
        this.correoP = correoP;
        this.tipoDeSangreP = tipoDeSangreP;
        this.edadD = edadD;
        this.prioridad = prioridad;
    }

    @Override
    public String toString() {
        return nombreP + "," + documentoP + "," + celularP + "," + correoP + "," + tipoDeSangreP + "," + edadD + "," + prioridad;
    }


    public void setNombreP(String nombreP) {
        this.nombreP = nombreP;
    }

    public void setDocumentoP(String documentoP) {
        this.documentoP = documentoP;
    }

    public void setCelularP(String celularP) {
        this.celularP = celularP;
    }

    public void setCorreoP(String correoP) {
        this.correoP = correoP;
    }

    public void setTipoDeSangreP(String tipoDeSangreP) {
        this.tipoDeSangreP = tipoDeSangreP;
    }

    public void setEdadD(int edadD) {
        this.edadD = edadD;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public String getNombre() {
        return nombreP;
    }

    public String getDocumento() {
        return documentoP;
    }

    public String getCelular() {
        return celularP;
    }

    public String getCorreo() {
        return correoP;
    }

    public String getTipoSangre() {
        return tipoDeSangreP;
    }

    public int getEdad() {
        return edadD;
    }

    public int getPrioridad() {
        return prioridad;
    }
}

