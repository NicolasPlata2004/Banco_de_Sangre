package Clases;

public class Usuario {
    private String nombreU;
    private String tipo;

    public Usuario(String nombreU, String tipo) {

        this.nombreU = nombreU;
        this.tipo = tipo;
    }

    public void setNombreU(String nombreU) {
        this.nombreU = nombreU;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNombreU() {
        return nombreU;
    }

    public String getTipo() {
        return tipo;
    }
}

