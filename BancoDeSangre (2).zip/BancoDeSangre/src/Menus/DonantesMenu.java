package Menus;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import core.*;
import javafx.scene.control.*;
import Clases.*;
import util.*;
import javafx.geometry.Insets;

public class DonantesMenu extends Application {
    private BancoDeSangre banco;
    public DonantesMenu(BancoDeSangre banco) {
        this.banco = banco;
    }

    @Override
    public void start(Stage primaryStage) {


        // Campos de texto para ingresar datos del donante
        TextField nombreTextField = createTextField("Nombre");
        TextField documentoTextField = createTextField("Documento");
        TextField celularTextField = createTextField("Celular");
        TextField correoTextField = createTextField("Correo");
        TextField tipoSangreTextField = createTextField("Tipo de Sangre");
        TextField edadTextField = createTextField("Edad");

        Label resultadoLabel = new Label();

        TextArea donantesTextArea = new TextArea();
        donantesTextArea.setEditable(false);
        donantesTextArea.setWrapText(true);
        donantesTextArea.setPrefHeight(200);

        Button agregarDonanteButton = new Button("Agregar Donante");
        agregarDonanteButton.getStyleClass().add("boton-agregar");
        agregarDonanteButton.setOnAction(e -> agregarDonanteDesdeInterfaz(
                nombreTextField, documentoTextField, celularTextField,
                correoTextField, tipoSangreTextField, edadTextField,
                resultadoLabel, donantesTextArea
        ));

        Button eliminarDonanteButton = new Button("Eliminar Donante");
        eliminarDonanteButton.getStyleClass().add("boton-eliminar");
        eliminarDonanteButton.setOnAction(e -> eliminarDonanteDesdeInterfaz(documentoTextField.getText(), resultadoLabel));

        Button mostrarDonantesButton = new Button("Mostrar Donantes");
        mostrarDonantesButton.getStyleClass().add("boton-mostrar");
        mostrarDonantesButton.setOnAction(e -> mostrarDonantesEnInterfaz(donantesTextArea));

        Button VerHistorialDonantesButton = new Button("ver Historial");
        VerHistorialDonantesButton.getStyleClass().add("boton-Historial");
        VerHistorialDonantesButton.setOnAction(e -> mostrarHistorialEnInterfaz(donantesTextArea));

        Button retrocederButton = new Button("Retroceder");
        retrocederButton.getStyleClass().add("boton-retroceder");
        retrocederButton.setOnAction(e -> primaryStage.close());

        VBox donantesLayout = new VBox(10);
        donantesLayout.setPadding(new Insets(20));
        donantesLayout.getStyleClass().add("vbox");
        donantesLayout.getChildren().addAll(
                new Label("Banco de Sangre - Ingrese los datos del donante:"),
                nombreTextField, documentoTextField, celularTextField,
                correoTextField, tipoSangreTextField, edadTextField,
                agregarDonanteButton, eliminarDonanteButton,
                mostrarDonantesButton, VerHistorialDonantesButton, donantesTextArea,
                resultadoLabel, retrocederButton
        );

        Scene donantesScene = new Scene(donantesLayout, 1200, 800);

        primaryStage.setScene(donantesScene);

        primaryStage.setOnCloseRequest(event -> {
            // Reiniciar la aplicación al cerrar la ventana
            banco = new BancoDeSangre();  // Asegúrate de tener un constructor predeterminado en BancoDeSangre
        });
        primaryStage.show();
    }


    private TextField createTextField(String placeholder) {
        TextField textField = new TextField();
        textField.setPromptText(placeholder);
        return textField;
    }

    private void agregarDonanteDesdeInterfaz(TextField nombreTextField, TextField documentoTextField,
                                             TextField celularTextField, TextField correoTextField,
                                             TextField tipoSangreTextField, TextField edadTextField,
                                             Label resultadoLabel, TextArea donantesTextArea) {
        try {
            String nombreD = nombreTextField.getText();
            String documentoD = documentoTextField.getText();
            String celularD = celularTextField.getText();
            String correoD = correoTextField.getText();
            String tipoSangreD = tipoSangreTextField.getText();
            int edadDonante = Integer.parseInt(edadTextField.getText());

            Donante nuevoDonante = new Donante(nombreD, documentoD, celularD, correoD, tipoSangreD, edadDonante);
            banco.agregarDonante(nuevoDonante);
            banco.guardarDatosDonantes("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosDonantes.txt");
            clearTextFields(nombreTextField, documentoTextField, celularTextField, correoTextField, tipoSangreTextField, edadTextField);
            resultadoLabel.setText("Donante agregado exitosamente.");
            mostrarDonantesEnInterfaz(donantesTextArea);  // Actualizar la lista de donantes mostrada
        } catch (NumberFormatException e) {
            resultadoLabel.setText("Error: La edad debe ser un número.");
        }
    }

    private void eliminarDonanteDesdeInterfaz(String documentoD, Label resultadoLabel) {
        // Lógica para eliminar donante del banco
        banco.eliminarDonante(documentoD);
        resultadoLabel.setText("Donante eliminado exitosamente.");
    }
    private void buscarDonanteDesdeInterfaz(String documentoD, TextArea pacientesTextArea){
        Donante donanteEncontrado = banco.buscarDonanteEnColaPorDocumento(documentoD);

        if (donanteEncontrado != null) {
            String resultado = "Paciente encontrado:\n" +
                    "Nombre: " + donanteEncontrado.getNombre() + " " +
                    "Documento: " + donanteEncontrado.getDocumento() + " " +
                    "Celular: " + donanteEncontrado.getCelular() + " " +
                    "Correo: " + donanteEncontrado.getCorreo() + " " +
                    "Tipo de Sangre: " + donanteEncontrado.getTipoSangre() + " " +
                    "Edad: " + donanteEncontrado.getEdad();


            pacientesTextArea.setText(resultado);
        } else {
            pacientesTextArea.setText("Paciente no encontrado");
        }
    }
    private void mostrarDonantesEnInterfaz(TextArea donantesTextArea) {
        donantesTextArea.setText(banco.obtenerColaDonantes());
    }
    private void mostrarHistorialEnInterfaz(TextArea donantesTextArea) {
        donantesTextArea.setText(banco.obtenerHistorialDonantes());
    }
    private void clearTextFields(TextField... textFields) {
        for (TextField textField : textFields) {
            textField.clear();
        }
    }
    public VBox createDonantesLayout() {

        // Campos de texto para ingresar datos del donante
        TextField nombreTextField = createTextField("Nombre");
        TextField documentoTextField = createTextField("Documento");
        TextField celularTextField = createTextField("Celular");
        TextField correoTextField = createTextField("Correo");
        TextField tipoSangreTextField = createTextField("Tipo de Sangre");
        TextField edadTextField = createTextField("Edad");

        Label resultadoLabel = new Label();

        TextArea donantesTextArea = new TextArea();
        donantesTextArea.setEditable(false);
        donantesTextArea.setWrapText(true);
        donantesTextArea.setPrefHeight(200);

        Button agregarDonanteButton = new Button("Agregar Donante");
        agregarDonanteButton.getStyleClass().add("boton-agregar");
        agregarDonanteButton.setOnAction(e -> agregarDonanteDesdeInterfaz(
                nombreTextField, documentoTextField, celularTextField,
                correoTextField, tipoSangreTextField, edadTextField,
                resultadoLabel, donantesTextArea
        ));
        Button buscarDonanteButton = new Button("Buscar Pacientes");
        buscarDonanteButton.getStyleClass().add("boton-Buscar");
        buscarDonanteButton.setOnAction(e -> buscarDonanteDesdeInterfaz(documentoTextField.getText(), donantesTextArea));

        Button eliminarDonanteButton = new Button("Eliminar Donante");
        eliminarDonanteButton.getStyleClass().add("boton-eliminar");
        eliminarDonanteButton.setOnAction(e -> eliminarDonanteDesdeInterfaz(documentoTextField.getText(), resultadoLabel));

        Button mostrarDonantesButton = new Button("Mostrar Donantes");
        mostrarDonantesButton.getStyleClass().add("boton-mostrar");
        mostrarDonantesButton.setOnAction(e -> mostrarDonantesEnInterfaz(donantesTextArea));

        Button verHistorialDonantesButton = new Button("Ver Historial");
        verHistorialDonantesButton.getStyleClass().add("boton-Historial");
        verHistorialDonantesButton.setOnAction(e -> mostrarHistorialEnInterfaz(donantesTextArea));

        VBox DonantesLayout = new VBox(10);
        DonantesLayout.setPadding(new Insets(20));
        DonantesLayout.getStyleClass().add("vbox");
        DonantesLayout.getChildren().addAll(
                new Label("Banco de Sangre - Ingrese los datos del donante:"),
                nombreTextField, documentoTextField, celularTextField,
                correoTextField, tipoSangreTextField, edadTextField,
                agregarDonanteButton,buscarDonanteButton, eliminarDonanteButton,
                mostrarDonantesButton, verHistorialDonantesButton, donantesTextArea,
                resultadoLabel
        );

        return DonantesLayout;
    }
    public void mostrar() {
        javafx.application.Platform.runLater(() -> {
            try {
                start(new Stage());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }


    public static void main(String[] args) {

        launch(args);
    }
}
