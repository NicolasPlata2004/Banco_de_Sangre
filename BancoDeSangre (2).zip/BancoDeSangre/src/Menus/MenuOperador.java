package Menus;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;
import core.*;

public class MenuOperador extends Application {
    private DonantesMenu donantesMenu;
    private PacientesMenu pacientesMenu;
    private PacientesPrioritariosMenu pacientesPrioritariosMenu;
    private BancoDeSangre banco;

    public MenuOperador() {
        this.banco = new BancoDeSangre();  // Asegúrate de tener un constructor predeterminado en BancoDeSangre
        this.donantesMenu = new DonantesMenu(banco);
        this.pacientesMenu = new PacientesMenu(banco);
        this.pacientesPrioritariosMenu = new PacientesPrioritariosMenu(banco);
    }

    @Override
    public void start(Stage primaryStage) {
        cargarDatosIniciales(banco);
        primaryStage.setTitle("Banco de Sangre - Menú de Operador");

        TabPane tabPane = new TabPane();
        Tab donantesTab = new Tab("Donantes");
        Tab pacientesTab = new Tab("Pacientes");
        Tab pacientesPrioritariosTab = new Tab("Pacientes Prioritarios");

        donantesTab.setContent(donantesMenu.createDonantesLayout());
        pacientesTab.setContent(pacientesMenu.createPacientesLayout());
        pacientesPrioritariosTab.setContent(pacientesPrioritariosMenu.createPacientesPrioritariosLayout());

        tabPane.getTabs().addAll(donantesTab, pacientesTab, pacientesPrioritariosTab);

        Scene scene = new Scene(tabPane, 1200, 700);
        scene.getStylesheets().add(getClass().getResource("estilosMenuOperador.css").toExternalForm());
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    private void cargarDatosIniciales(BancoDeSangre banco) {
        // Cargar datos desde archivos al iniciar la aplicación
        banco.cargarArbolDesdeArchivo("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosArbolPrioritarioPacientes.txt");
        banco.cargarDatosDonantes("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosDonantes.txt");
        banco.cargarHistorialDonantes("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/HistorialDonantes.txt");
        banco.cargarDatosPacientes("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosPacientes.txt");
        banco.cargarHistorialPacientes("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/HistorialPacientes.txt");
    }
}

