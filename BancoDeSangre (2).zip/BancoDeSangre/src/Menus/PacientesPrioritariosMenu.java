package Menus;
import Clases.*;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import core.*;
import javafx.application.Application;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.Scene;
import javafx.stage.*;
import java.io.*;
import javafx.application.Application;

public class PacientesPrioritariosMenu  extends Application {

    private BancoDeSangre banco;

    public PacientesPrioritariosMenu(BancoDeSangre banco) {
        this.banco = banco;
    }

    @Override
    public void start(Stage primaryStage) {


        // Campos de texto para ingresar datos del donante
        TextField nombreTextField = createTextField("Nombre");
        TextField documentoTextField = createTextField("Documento");
        TextField celularTextField = createTextField("Celular");
        TextField correoTextField = createTextField("Correo");
        TextField tipoSangreTextField = createTextField("Tipo de Sangre");
        TextField edadTextField = createTextField("Edad");
        TextField prioridadTextField = createTextField("prioridad");

        Label resultadoLabel = new Label();

        TextArea pacienteTextArea = new TextArea();
        pacienteTextArea.setEditable(false);
        pacienteTextArea.setWrapText(true);
        pacienteTextArea.setPrefHeight(200);

        Button agregarPacienteButton = new Button("Agregar Paciente");
        agregarPacienteButton.getStyleClass().add("boton-agregar");
        agregarPacienteButton.setOnAction(e -> agregarPacienteDesdeInterfaz(
                nombreTextField, documentoTextField, celularTextField,
                correoTextField, tipoSangreTextField, edadTextField, prioridadTextField,
                resultadoLabel, pacienteTextArea
        ));

        Button eliminarPacientePrioritarioButton = new Button("Eliminar Paciente prioritario");
        eliminarPacientePrioritarioButton.getStyleClass().add("boton-eliminar");
        eliminarPacientePrioritarioButton.setOnAction(e -> eliminarPacienteEnArbol(documentoTextField.getText(), resultadoLabel));


        Button buscarPacientePrioritarioButton = new Button("Buscar Pacientes prioritario");
        buscarPacientePrioritarioButton.getStyleClass().add("boton-Buscar");
        buscarPacientePrioritarioButton.setOnAction(e -> buscarPacienteDesdeInterfazEnArbol(documentoTextField.getText(), pacienteTextArea));

        Button mostrarPacientesPrioritariosButton = new Button("Mostrar Pacientes prioritarios");
        mostrarPacientesPrioritariosButton.getStyleClass().add("boton-mostrar");
        mostrarPacientesPrioritariosButton.setOnAction(e -> mostrarPacientesPrioritariosEnInterfaz(pacienteTextArea));

        Button retrocederButton = new Button("Retroceder");
        retrocederButton.getStyleClass().add("boton-retroceder");
        retrocederButton.setOnAction(e -> primaryStage.close());

        VBox pacientesLayout = new VBox(10);
        pacientesLayout.setPadding(new Insets(20));
        pacientesLayout.getStyleClass().add("vbox");
        pacientesLayout.getChildren().addAll(
                new Label("Banco de Sangre - Ingrese los datos del donante:"),
                nombreTextField, documentoTextField, celularTextField,
                correoTextField, tipoSangreTextField, edadTextField, prioridadTextField,
                agregarPacienteButton,  eliminarPacientePrioritarioButton,  buscarPacientePrioritarioButton,
                mostrarPacientesPrioritariosButton,  pacienteTextArea,
                resultadoLabel, retrocederButton
        );

        Scene pacientesScene = new Scene(pacientesLayout, 1200
                , 700);
        pacientesScene.getStylesheets().add(getClass().getResource("estilosMenuPacientesPrioritarioOp.css").toExternalForm());
        primaryStage.setScene(pacientesScene);

        primaryStage.setOnCloseRequest(event -> {
            // Reiniciar la aplicación al cerrar la ventana
            banco = new BancoDeSangre();  // Asegúrate de tener un constructor predeterminado en BancoDeSangre
        });
        primaryStage.show();
    }

    private TextField createTextField(String placeholder) {
        TextField textField = new TextField();
        textField.setPromptText(placeholder);
        return textField;
    }

    public void agregarPacienteDesdeInterfaz(TextField nombreTextField, TextField documentoTextField,
                                             TextField celularTextField, TextField correoTextField,
                                             TextField tipoSangreTextField, TextField edadTextField,
                                             TextField prioridadTextField, Label resultadoLabel,
                                             TextArea donantesTextArea) {
        try {
            String nombreP = nombreTextField.getText();
            String documentoP = documentoTextField.getText();
            String celularP = celularTextField.getText();
            String correoP = correoTextField.getText();
            String tipoDeSangreP = tipoSangreTextField.getText();
            int edadPaciente = Integer.parseInt(edadTextField.getText());
            int prioridad = Integer.parseInt(prioridadTextField.getText());

            Paciente nuevoPaciente = new Paciente(nombreP, documentoP, celularP, correoP, tipoDeSangreP, edadPaciente, prioridad);

            banco.agregarPacientePrioritario(nuevoPaciente);


            clearTextFields(nombreTextField, documentoTextField, celularTextField, correoTextField, tipoSangreTextField, edadTextField);
            resultadoLabel.setText("Paciente agregado exitosamente.");
            mostrarPacientesPrioritariosEnInterfaz(donantesTextArea);  // Actualizar la lista de donantes mostrada
        } catch (NumberFormatException e) {
            resultadoLabel.setText("Error: La edad debe ser un número.");
        }
    }



    private void eliminarPacienteDesdeInterfaz(String documentoP, Label resultadoLabel) {
        // Lógica para eliminar donante del banco
        banco.eliminarPaciente(documentoP);
        resultadoLabel.setText("Paciente eliminado exitosamente.");
    }
    private void eliminarPacienteEnArbol(String documentoP, Label resultadoLabel) {
        if (documentoP.isEmpty()) {
            resultadoLabel.setText("Ingrese un número de documento válido.");
            return;
        }

        // Llamamos al método de eliminación en la clase BancoDeSangre
        banco.eliminarPacienteArbolPorDocumento(documentoP);

        resultadoLabel.setText("Paciente eliminado exitosamente.");
    }

    private void buscarPacienteDesdeInterfazEnArbol(String documentoP, TextArea pacientesTextArea){
        Paciente pacienteEncontrado = banco.buscarPacientePorDocumentoEnArbol(documentoP);

        if (pacienteEncontrado != null) {
            String resultado = "Paciente encontrado: \n" +
                    "Nombre: " + pacienteEncontrado.getNombre() + " " +
                    "Documento: " + pacienteEncontrado.getDocumento() + " " +
                    "Celular: " + pacienteEncontrado.getCelular() + " " +
                    "Correo: " + pacienteEncontrado.getCorreo() + " " +
                    "Tipo de Sangre: " + pacienteEncontrado.getTipoSangre() + " " +
                    "Edad: " + pacienteEncontrado.getEdad() + " " +
                    "Prioridad: " + pacienteEncontrado.getPrioridad();

            pacientesTextArea.setText(resultado);
        } else {
            pacientesTextArea.setText("Paciente no encontrado");
        }
    }



    private void mostrarPacientesPrioritariosEnInterfaz(TextArea pacientesTextArea) {
        pacientesTextArea.setText(banco.obtenerArbolPacientes());
    }

    private void clearTextFields(TextField... textFields) {
        for (TextField textField : textFields) {
            textField.clear();
        }
    }
    public VBox createPacientesPrioritariosLayout() {
        // Aquí defines la estructura y los elementos del layout para pacientes
        TextField nombreTextField = createTextField("Nombre");
        TextField documentoTextField = createTextField("Documento");
        TextField celularTextField = createTextField("Celular");
        TextField correoTextField = createTextField("Correo");
        TextField tipoSangreTextField = createTextField("Tipo de Sangre");
        TextField edadTextField = createTextField("Edad");
        TextField prioridadTextField = createTextField("Prioridad");

        Label resultadoLabel = new Label();

        TextArea pacienteTextArea = new TextArea();
        pacienteTextArea.setEditable(false);
        pacienteTextArea.setWrapText(true);
        pacienteTextArea.setPrefHeight(200);

        Button agregarPacienteButton = new Button("Agregar Paciente");
        agregarPacienteButton.getStyleClass().add("boton-agregar");
        agregarPacienteButton.setOnAction(e -> agregarPacienteDesdeInterfaz(
                nombreTextField, documentoTextField, celularTextField,
                correoTextField, tipoSangreTextField, edadTextField, prioridadTextField,
                resultadoLabel, pacienteTextArea
        ));

        Button eliminarPacientePrioritarioButton = new Button("Eliminar Paciente prioritario");
        eliminarPacientePrioritarioButton.getStyleClass().add("boton-eliminar");
        eliminarPacientePrioritarioButton.setOnAction(e -> eliminarPacienteEnArbol(documentoTextField.getText(), resultadoLabel));


        Button buscarPacientePrioritarioButton = new Button("Buscar Pacientes prioritario");
        buscarPacientePrioritarioButton.getStyleClass().add("boton-Buscar");
        buscarPacientePrioritarioButton.setOnAction(e -> buscarPacienteDesdeInterfazEnArbol(documentoTextField.getText(), pacienteTextArea));

        Button mostrarPacientesPrioritariosButton = new Button("Mostrar Pacientes prioritarios");
        mostrarPacientesPrioritariosButton.getStyleClass().add("boton-mostrar");
        mostrarPacientesPrioritariosButton.setOnAction(e -> mostrarPacientesPrioritariosEnInterfaz(pacienteTextArea));

        VBox pacientesLayout = new VBox(10);
        pacientesLayout.setPadding(new Insets(20));
        pacientesLayout.getStyleClass().add("vbox");
        pacientesLayout.getChildren().addAll(
                new Label("Banco de Sangre - Ingrese los datos del donante:"),
                nombreTextField, documentoTextField, celularTextField,
                correoTextField, tipoSangreTextField, edadTextField, prioridadTextField,
                agregarPacienteButton, buscarPacientePrioritarioButton, eliminarPacientePrioritarioButton,
                mostrarPacientesPrioritariosButton,pacienteTextArea,resultadoLabel
        );

        return pacientesLayout;
    }

    public void mostrar() {
        javafx.application.Platform.runLater(() -> {
            try {
                start(new Stage());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }


    public static void main(String[] args) {
        launch(args);
    }
}