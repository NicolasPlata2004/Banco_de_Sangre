package core;
import Clases.*;
import util.*;
import java.io.*;
import java.util.*;
public class BancoDeSangre {
    private Cola<Donante> colaEsperaDonantes = new Cola<>();
    private ListaEnlazada<Donante> historialDonantes = new ListaEnlazada<>();
    private Cola<Paciente> colaEsperaPacientes = new Cola<>();
    private ListaEnlazada<Paciente> historialPacientes = new ListaEnlazada<>();

    private ArbolPrioritario<Paciente> arbolPrioridadPacientes = new ArbolPrioritario<>();


    public void cargarDatosDonantes(String nombreArchivo) {
        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length >= 6) {
                    Donante donante = new Donante(partes[0], partes[1], partes[2], partes[3], partes[4], Integer.parseInt(partes[5]));
                    agregarDonante(donante);
                } else {
                    System.err.println("Error en el formato de la línea: " + linea);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cargarHistorialDonantes(String nombreArchivo) {
        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length >= 6) {
                    Donante donante = new Donante(partes[0], partes[1], partes[2], partes[3], partes[4], Integer.parseInt(partes[5]));
                    historialDonantes.agregar(donante);
                } else {
                    System.err.println("Error en el formato de la línea: " + linea);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cargarDatosPacientes(String nombreArchivo) {
        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length >= 7) {
                    Paciente paciente = new Paciente(partes[0], partes[1], partes[2], partes[3], partes[4], Integer.parseInt(partes[5]), Integer.parseInt(partes[6]));
                    agregarPaciente(paciente);
                } else {
                    System.err.println("Error en el formato de la línea: " + linea);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cargarHistorialPacientes(String nombreArchivo) {
        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length >= 7) {
                    Paciente paciente = new Paciente(partes[0], partes[1], partes[2], partes[3], partes[4], Integer.parseInt(partes[5]), Integer.parseInt(partes[6]));
                    historialPacientes.agregar(paciente);
                } else {
                    System.err.println("Error en el formato de la línea: " + linea);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void guardarDatosDonantes(String nombreArchivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreArchivo))) {
            // Guardar elementos de la cola de espera en el archivo
            Cola<Donante> colaTemp = new Cola<>();
            while (!colaEsperaDonantes.estaVacia()) {
                Donante donante = colaEsperaDonantes.desencolar();
                bw.write(donante.toString());
                bw.newLine();
                colaTemp.encolar(donante);
            }

            // Restaurar la cola de espera original
            while (!colaTemp.estaVacia()) {
                colaEsperaDonantes.encolar(colaTemp.desencolar());
            }

            System.out.println("Datos de Donante guardados exitosamente en la cola de espera.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void guardarHistorialDonantes(String nombreArchivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreArchivo, true))) {

            Nodo<Donante> temp = historialDonantes.obtenerCabeza();
            while (temp != null) {
                bw.write(temp.valor.toString());
                bw.newLine();
                temp = temp.siguiente;
            }

            System.out.println("Datos de Donante en el historial guardados exitosamente en el archivo.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void guardarDatosPacientes(String nombreArchivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreArchivo))) {
            // Guardar elementos de la cola de espera en el archivo
            Cola<Paciente> colaTemp = new Cola<>();
            while (!colaEsperaPacientes.estaVacia()) {
                Paciente paciente = colaEsperaPacientes.desencolar();
                bw.write(paciente.toString());
                bw.newLine();
                colaTemp.encolar(paciente);
            }

            // Restaurar la cola de espera original
            while (!colaTemp.estaVacia()) {
                colaEsperaPacientes.encolar(colaTemp.desencolar());
            }

            System.out.println("Datos de pacientes guardados exitosamente en la cola de espera.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void guardarHistorialPacientes(String nombreArchivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreArchivo, true))) {

            Nodo<Paciente> temp = historialPacientes.obtenerCabeza();
            while (temp != null) {
                bw.write(temp.valor.toString());
                bw.newLine();
                temp = temp.siguiente;
            }

            System.out.println("Datos de pacientes en el historial guardados exitosamente en el archivo.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void agregarDonante(Donante donante) {
        colaEsperaDonantes.encolar(donante);
    }


    public void agregarPacienteHistorial(Paciente paciente) {
        historialPacientes.agregar(paciente);
    }

    public void agregarDonanteHistorial(Donante donante) {
        historialDonantes.agregar(donante);
    }

    public void eliminarDonante(String documentoD) {
        Donante donanteAEliminar = null;

        // Buscar al paciente en la cola de espera
        Cola<Donante> colaEsperaTemp = new Cola<>();
        while (!colaEsperaDonantes.estaVacia()) {
            Donante donante = colaEsperaDonantes.desencolar();
            if (donante.documentoD.equals(documentoD)) {
                donanteAEliminar = donante;
                System.out.println("Donante encontrado en la cola de espera y eliminado.");
                agregarDonanteHistorial(donante);
            } else {
                colaEsperaTemp.encolar(donante);
            }
        }
        colaEsperaDonantes = colaEsperaTemp;

        if (donanteAEliminar == null) {
            System.out.println("No se encontró un Donante con el documento proporcionado en la cola de espera.");
            return;
        }

        // Actualizar el archivo de texto
        guardarDatosDonantes("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosDonantes.txt");

        System.out.println("Paciente eliminado del archivo de texto.");
    }

    public void eliminarPaciente(String documentoP) {
        Paciente pacienteAEliminar = null;

        // Buscar al paciente en la cola de espera
        Cola<Paciente> colaEsperaTemp = new Cola<>();
        while (!colaEsperaPacientes.estaVacia()) {
            Paciente paciente = colaEsperaPacientes.desencolar();
            if (paciente.documentoP.equals(documentoP)) {
                pacienteAEliminar = paciente;
                System.out.println("Paciente encontrado en la cola de espera y eliminado.");
                agregarPacienteHistorial(paciente);
            } else {
                colaEsperaTemp.encolar(paciente);
            }
        }
        colaEsperaPacientes = colaEsperaTemp;

        if (pacienteAEliminar == null) {
            System.out.println("No se encontró un Paciente con el documento proporcionado en la cola de espera.");
            return;
        }

        // Actualizar el archivo de texto
        guardarDatosPacientes("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosPacientes.txt");

        System.out.println("Paciente eliminado del archivo de texto.");
    }

    public void mostrarHistorialDonantes() {
        System.out.println("Historial de donantes:");

        if (historialDonantes.estaVacia()) {
            System.out.println("El historial de donantes está vacío.");
            return;
        }

        Nodo<Donante> temp = historialDonantes.obtenerCabeza();
        while (temp != null) {
            System.out.println("Nombre: " + temp.valor.nombreD +
                    ", Documento: " + temp.valor.documentoD +
                    ", Correo: " + temp.valor.correoD +
                    ", celular: " + temp.valor.celularD +
                    ", Tipo de Sangre: " + temp.valor.tipoSangreD +
                    ", Edad: " + temp.valor.edadD);
            temp = temp.siguiente;
        }
    }

    public void mostrarHistorialPacientes() {
        System.out.println("Historial de pacientes:");

        if (historialPacientes.estaVacia()) {
            System.out.println("El historial de pacientes está vacío.");
            return;
        }

        Nodo<Paciente> temp = historialPacientes.obtenerCabeza();
        while (temp != null) {
            System.out.println("Nombre: " + temp.valor.nombreP +
                    ", Documento: " + temp.valor.documentoP +
                    ", Correo: " + temp.valor.correoP +
                    ", celular: " + temp.valor.celularP +
                    ", Tipo de Sangre: " + temp.valor.tipoDeSangreP +
                    ", Edad: " + temp.valor.edadD);
            temp = temp.siguiente;
        }
    }

    public void mostrarDonantes() {
        System.out.println("Lista de Donante en la cola de espera:");

        if (colaEsperaDonantes.estaVacia()) {
            System.out.println("La cola de espera de Donante está vacía.");
            return;
        }

        // Crear una cola temporal para mostrar los pacientes sin modificar la original
        Cola<Donante> colaTemp = new Cola<>();
        while (!colaEsperaDonantes.estaVacia()) {
            Donante donante = colaEsperaDonantes.desencolar();
            System.out.println("Nombre: " + donante.nombreD +
                    ", Documento: " + donante.documentoD +
                    ", Correo: " + donante.correoD +
                    ", celular: " + donante.celularD +
                    ", Tipo de Sangre: " + donante.tipoSangreD +
                    ", Edad: " + donante.edadD);
            colaTemp.encolar(donante);
        }

        // Restaurar la cola de espera original
        while (!colaTemp.estaVacia()) {
            colaEsperaDonantes.encolar(colaTemp.desencolar());
        }
    }


    public void mostrarPacientes() {
        System.out.println("Lista de pacientes en la cola de espera:");

        if (colaEsperaPacientes.estaVacia()) {
            System.out.println("La cola de espera de pacientes está vacía.");
            return;
        }

        // Crear una cola temporal para mostrar los pacientes sin modificar la original
        Cola<Paciente> colaTemp = new Cola<>();
        while (!colaEsperaPacientes.estaVacia()) {
            Paciente paciente = colaEsperaPacientes.desencolar();
            System.out.println("Nombre: " + paciente.nombreP +
                    ", Documento: " + paciente.documentoP +
                    ", Correo: " + paciente.correoP +
                    ", celular: " + paciente.celularP +
                    ", Tipo de Sangre: " + paciente.tipoDeSangreP +
                    ", Edad: " + paciente.edadD);
            colaTemp.encolar(paciente);
        }

        // Restaurar la cola de espera original
        while (!colaTemp.estaVacia()) {
            colaEsperaPacientes.encolar(colaTemp.desencolar());
        }
    }

    public void BuscarDonantesPorDoc(String DocumentoD) {
        System.out.println(" Donantes con Documeno " + DocumentoD + " en la cola de espera:");

        Cola<Donante> colaTemp = new Cola<>();
        boolean encontrado = false;

        while (!colaEsperaDonantes.estaVacia()) {
            Donante donante = colaEsperaDonantes.desencolar();
            colaTemp.encolar(donante);

            if (donante.documentoD.trim().equalsIgnoreCase(DocumentoD.trim())) {
                System.out.println("Nombre: " + donante.nombreD +
                        ", Documento: " + donante.documentoD +
                        ", Correo: " + donante.correoD +
                        ", Celular: " + donante.celularD +
                        ", Tipo de Sangre: " + donante.tipoSangreD +
                        ", Edad: " + donante.edadD);
                encontrado = true;
            }
        }

        // Restaurar la cola de espera original
        while (!colaTemp.estaVacia()) {
            colaEsperaDonantes.encolar(colaTemp.desencolar());
        }

        if (!encontrado) {
            System.out.println("No se encontraron Donantes con tipo de sangre " + DocumentoD + " en la cola de espera.");
        }
    }

    public void eliminarDonanteDesdeCosnsola() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el documento del Donante que se desea eliminar: ");
        String documentoEliminar = scanner.nextLine();

        eliminarDonante(documentoEliminar);
    }

    public void eliminarPacienteDesdeConsola() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el documento del Paciente que se desea eliminar: ");
        String documentoEliminar = scanner.nextLine();


        eliminarPaciente(documentoEliminar);


    }


    public Paciente buscarPacienteEnColaPorDocumento(String documento) {
        return colaEsperaPacientes.buscarPorDocumentoPaciente(documento);
    }

    public Donante buscarDonanteEnColaPorDocumento(String documento) {
        return colaEsperaDonantes.buscarPorDocumentoDonante(documento);
    }

    public void editarPaciente(String documentoP) {
        Paciente pacienteAEditar = null;

        // Buscar al paciente en la cola de espera
        Cola<Paciente> colaEsperaTemp = new Cola<>();
        while (!colaEsperaPacientes.estaVacia()) {
            Paciente paciente = colaEsperaPacientes.desencolar();
            if (paciente.documentoP.equals(documentoP)) {
                pacienteAEditar = paciente;
                System.out.println("Paciente encontrado en la cola de espera.");

                // Solicitar nuevos datos al usuario
                Scanner scanner = new Scanner(System.in);
                System.out.println("Ingrese los nuevos datos del paciente:");

                System.out.print("Nombre: ");
                paciente.nombreP = scanner.nextLine();

                System.out.print("Celular: ");
                paciente.celularP = scanner.nextLine();

                System.out.print("Correo: ");
                paciente.correoP = scanner.nextLine();

                System.out.print("Tipo de Sangre: ");
                paciente.tipoDeSangreP = scanner.nextLine();

                System.out.print("Edad: ");
                try {
                    paciente.edadD = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Error al leer la edad. Asegúrate de ingresar un número entero.");
                    return;
                }

                System.out.println("Paciente editado exitosamente.");
            }
            colaEsperaTemp.encolar(paciente);
        }
        colaEsperaPacientes = colaEsperaTemp;

        if (pacienteAEditar == null) {
            System.out.println("No se encontró un Paciente con el documento proporcionado en la cola de espera.");
        }

        // Actualizar el archivo de texto
        guardarDatosPacientes("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosPacientes.txt");
    }

    public void editarDonante(String documentoD) {
        Donante donanteAEditar = null;

        // Buscar al donante en la cola de espera
        Cola<Donante> colaEsperaTemp = new Cola<>();
        while (!colaEsperaDonantes.estaVacia()) {
            Donante donante = colaEsperaDonantes.desencolar();
            if (donante.documentoD.equals(documentoD)) {
                donanteAEditar = donante;
                System.out.println("Donante encontrado en la cola de espera.");

                // Solicitar nuevos datos al usuario
                Scanner scanner = new Scanner(System.in);
                System.out.println("Ingrese los nuevos datos del donante:");

                System.out.print("Nombre: ");
                donante.nombreD = scanner.nextLine();

                System.out.print("Celular: ");
                donante.celularD = scanner.nextLine();

                System.out.print("Correo: ");
                donante.correoD = scanner.nextLine();

                System.out.print("Tipo de Sangre: ");
                donante.tipoSangreD = scanner.nextLine();

                System.out.print("Edad: ");
                try {
                    donante.edadD = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Error al leer la edad. Asegúrate de ingresar un número entero.");
                    return;
                }

                System.out.println("Donante editado exitosamente.");
            }
            colaEsperaTemp.encolar(donante);
        }
        colaEsperaDonantes = colaEsperaTemp;

        if (donanteAEditar == null) {
            System.out.println("No se encontró un Donante con el documento proporcionado en la cola de espera.");
        }

        // Actualizar el archivo de texto
        guardarDatosDonantes("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosDonantes.txt");
    }

    public void editarPacienteDesdeConsola() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el documento del Paciente que desea editar: ");
        String documentoEditar = scanner.nextLine();

        editarPaciente(documentoEditar);
    }

    public void editarDonanteDesdeConsola() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el documento del Donante que desea editar: ");
        String documentoEditar = scanner.nextLine();

        editarDonante(documentoEditar);
    }

    public String obtenerColaDonantes() {
        StringBuilder ColaDonantes = new StringBuilder();

        Cola<Donante> colaTemp = new Cola<>();
        while (!colaEsperaDonantes.estaVacia()) {
            Donante donante = colaEsperaDonantes.desencolar();
            ColaDonantes.append("Nombre: ").append(donante.nombreD)
                    .append(", Documento: ").append(donante.documentoD)
                    .append(", Correo: ").append(donante.correoD)
                    .append(", Celular: ").append(donante.celularD)
                    .append(", Tipo de Sangre: ").append(donante.tipoSangreD)
                    .append(", Edad: ").append(donante.edadD)
                    .append("\n");

            colaTemp.encolar(donante);
        }

        // Restaurar la cola de espera original
        while (!colaTemp.estaVacia()) {
            colaEsperaDonantes.encolar(colaTemp.desencolar());
        }

        return ColaDonantes.toString();
    }

    public String obtenerColaPacientes() {
        StringBuilder ColaPacientes = new StringBuilder();

        Cola<Paciente> colaTemp = new Cola<>();
        while (!colaEsperaPacientes.estaVacia()) {
            Paciente paciente = colaEsperaPacientes.desencolar();
            ColaPacientes.append("Nombre: ").append(paciente.nombreP)
                    .append(", Documento: ").append(paciente.documentoP)
                    .append(", Correo: ").append(paciente.correoP)
                    .append(", Celular: ").append(paciente.celularP)
                    .append(", Tipo de Sangre: ").append(paciente.tipoDeSangreP)
                    .append(", Edad: ").append(paciente.edadD)
                    .append(", Prioridad: ").append(paciente.prioridad)
                    .append("\n");

            colaTemp.encolar(paciente);
        }

        // Restaurar la cola de espera original
        while (!colaTemp.estaVacia()) {
            colaEsperaPacientes.encolar(colaTemp.desencolar());
        }

        return ColaPacientes.toString();
    }

    public String obtenerHistorialDonantes() {
        StringBuilder historial = new StringBuilder();

        Nodo<Donante> actual = obtenerCabezaDonantes();
        while (actual != null) {
            Donante donante = actual.valor;
            historial.append("Nombre: ").append(donante.getNombre())
                    .append(", Documento: ").append(donante.getDocumento())
                    .append(", Correo: ").append(donante.getCorreo())
                    .append(", Celular: ").append(donante.getCelular())
                    .append(", Tipo de Sangre: ").append(donante.getTipoSangre())
                    .append(", Edad: ").append(donante.getEdad())
                    .append("\n");

            actual = actual.siguiente;
        }

        return historial.toString();
    }

    public String obtenerHistorialPacientes() {
        StringBuilder historial = new StringBuilder();

        Nodo<Donante> actual = obtenerCabezaPacientes();
        while (actual != null) {
            Donante donante = actual.valor;
            historial.append("Nombre: ").append(donante.getNombre())
                    .append(", Documento: ").append(donante.getDocumento())
                    .append(", Correo: ").append(donante.getCorreo())
                    .append(", Celular: ").append(donante.getCelular())
                    .append(", Tipo de Sangre: ").append(donante.getTipoSangre())
                    .append(", Edad: ").append(donante.getEdad())
                    .append("\n");

            actual = actual.siguiente;
        }

        return historial.toString();
    }

    public Nodo<Donante> obtenerCabezaDonantes() {
        return historialDonantes.obtenerCabeza();
    }

    public Nodo<Donante> obtenerCabezaPacientes() {
        return historialDonantes.obtenerCabeza();
    }
    /*
    public void agregarPaciente(Paciente paciente) {
        if (paciente.getPrioridad() > 0) {
            arbolPrioridadPacientes.insertarConPrioridad(paciente.getPrioridad(), paciente);
            guardarArbolPrioritarioEnArchivo("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosArbolPrioritarioPacientes.txt");
        } else {
            colaEsperaPacientes.encolar(paciente);
            guardarDatosPacientes("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosPacientes.txt");
        }
    }
*/

    public void agregarPacientePrioritario(Paciente paciente) {
        arbolPrioridadPacientes.insertarConPrioridad(paciente.getPrioridad(), paciente);
        guardarArbolPrioritarioEnArchivo("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosArbolPrioritarioPacientes.txt");
    }

    public void agregarPaciente(Paciente paciente) {
        colaEsperaPacientes.encolar(paciente);
        guardarDatosPacientes("/Users/juanm/OneDrive/Escritorio/Universidad/EStructura de datos/Datos/DatosPacientes.txt");
    }

    public void guardarArbolPrioritarioEnArchivo(String nombreArchivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreArchivo, false))) {
            guardarArbolPrioritarioRecursivoEnOrdenInverso(arbolPrioridadPacientes.obtenerRaiz(), bw);
            System.out.println("Árbol prioritario guardado exitosamente en el archivo.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void guardarArbolPrioritarioRecursivoEnOrdenInverso(NodoPrioridad<Paciente> nodoActual, BufferedWriter writer) throws IOException {
        if (nodoActual != null) {
            // Recorrido inorden inverso
            guardarArbolPrioritarioRecursivoEnOrdenInverso(nodoActual.getHijoDerecho(), writer);

            // Agregar el valor al archivo
            writer.write(nodoActual.getValor().toString());
            writer.newLine();

            // Recorrido inorden inverso en el subárbol izquierdo
            guardarArbolPrioritarioRecursivoEnOrdenInverso(nodoActual.getHijoIzquierdo(), writer);
        }
    }

    public void cargarArbolDesdeArchivo(String nombreArchivo) {
        TemporalListaEnlazada<String> datosTemporales = new TemporalListaEnlazada<>();

        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                datosTemporales.agregar(linea);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return; // Sale del método si hay un error al leer el archivo
        }

        while (!datosTemporales.estaVacia()) {
            String linea = datosTemporales.obtenerCabeza().valor;
            String[] partes = linea.split(",");

            if (partes.length >= 7) {
                try {
                    String nombre = partes[0].replaceAll("\"", "");
                    String documento = partes[1].replaceAll("\"", "");
                    String correo = partes[2].replaceAll("\"", "");
                    String celular = partes[3].replaceAll("\"", "");
                    String tipoSangre = partes[4].replaceAll("\"", "");
                    int edad = Integer.parseInt(partes[5]);
                    int prioridad = Integer.parseInt(partes[6]);

                    Paciente paciente = new Paciente(nombre, documento, correo, celular, tipoSangre, edad, prioridad);
                    arbolPrioridadPacientes.insertarConPrioridad(paciente.getPrioridad(), paciente);
                } catch (NumberFormatException e) {
                    System.err.println("Error al convertir edad o prioridad a entero en la línea: " + linea);
                }
            } else {
                System.err.println("Error en el formato de la línea: " + linea);
            }

            datosTemporales.eliminar(linea);
        }
    }



    public String obtenerArbolPacientes() {
        return arbolPrioridadPacientes.obtenerRepresentacionArbolConDatos();
    }

    public Paciente buscarPacientePorDocumentoEnArbol(String documento) {
        return buscarPacientePorDocumentoEnArbolRecursivo(arbolPrioridadPacientes.obtenerRaiz(), documento);
    }

    private Paciente buscarPacientePorDocumentoEnArbolRecursivo(NodoPrioridad<Paciente> nodo, String documento) {
        if (nodo == null) {
            return null; // Nodo es nulo. El paciente no fue encontrado.
        }

        int comparacion = documento.compareToIgnoreCase(nodo.getValor().getDocumento());

        if (comparacion == 0) {
            return nodo.getValor(); // Paciente encontrado.
        } else if (comparacion > 0) {
            // Buscar en el subárbol derecho.
            return buscarPacientePorDocumentoEnArbolRecursivo(nodo.getHijoDerecho(), documento);
        } else {
            // Buscar en el subárbol izquierdo.
            return buscarPacientePorDocumentoEnArbolRecursivo(nodo.getHijoIzquierdo(), documento);
        }
    }


    public void eliminarPacienteArbolPorDocumento(String documento) {
        arbolPrioridadPacientes.setRaiz(eliminarPacienteRecursivo(arbolPrioridadPacientes.obtenerRaiz(), documento));
    }

    private NodoPrioridad<Paciente> eliminarPacienteRecursivo(NodoPrioridad<Paciente> nodo, String documento) {
        if (nodo == null) {
            // Nodo es nulo, el paciente no fue encontrado.
            return null;
        }

        int comparacion = documento.compareTo(nodo.getValor().getDocumento());

        if (comparacion > 0) {
            // Buscar en el subárbol derecho.
            nodo.setHijoDerecho(eliminarPacienteRecursivo(nodo.getHijoDerecho(), documento));
        } else if (comparacion < 0) {
            // Buscar en el subárbol izquierdo.
            nodo.setHijoIzquierdo(eliminarPacienteRecursivo(nodo.getHijoIzquierdo(), documento));
        } else {
            // Nodo encontrado, realizar la eliminación.
            if (nodo.getHijoIzquierdo() == null) {
                return nodo.getHijoDerecho();
            } else if (nodo.getHijoDerecho() == null) {
                return nodo.getHijoIzquierdo();
            }

            // Nodo con dos hijos, encontrar el sucesor in-order.
            NodoPrioridad<Paciente> sucesor = encontrarSucesorInOrder(nodo.getHijoDerecho());
            nodo.setValor(sucesor.getValor());

            // Eliminar el sucesor in-order.
            nodo.setHijoDerecho(eliminarPacienteRecursivo(nodo.getHijoDerecho(), sucesor.getValor().getDocumento()));
        }

        return nodo;
    }

    private NodoPrioridad<Paciente> encontrarSucesorInOrder(NodoPrioridad<Paciente> nodo) {
        while (nodo.getHijoIzquierdo() != null) {
            nodo = nodo.getHijoIzquierdo();
        }
        return nodo;
    }

}