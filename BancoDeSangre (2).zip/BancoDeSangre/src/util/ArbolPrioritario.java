package util;

import Clases.*;

import Clases.Paciente;

public class ArbolPrioritario<T> {
    private NodoPrioridad<T> raiz;
    public void setRaiz(NodoPrioridad<T> raiz) {
        this.raiz = raiz;
    }
    public void insertarConPrioridad(int prioridad, T valor) {
        NodoPrioridad<T> nuevoNodo = new NodoPrioridad<>(prioridad, valor);
        raiz = insertarConPrioridadRecursivo(raiz, nuevoNodo);
    }

    private NodoPrioridad<T> insertarConPrioridadRecursivo(NodoPrioridad<T> nodoActual, NodoPrioridad<T> nuevoNodo) {
        if (nodoActual == null) {
            return nuevoNodo; // Se llegó a una posición de inserción
        }

        T valorNuevo = nuevoNodo.getValor();

        // Si el valor ya existe en el árbol, no lo insertamos nuevamente
        if (nodoActual.getValor().equals(valorNuevo)) {
            return nodoActual;
        }

        if (nuevoNodo.getPrioridad() > nodoActual.getPrioridad()) {
            nodoActual.setHijoDerecho(insertarConPrioridadRecursivo(nodoActual.getHijoDerecho(), nuevoNodo));
        } else {
            nodoActual.setHijoIzquierdo(insertarConPrioridadRecursivo(nodoActual.getHijoIzquierdo(), nuevoNodo));
        }

        return nodoActual;
    }


    public NodoPrioridad<T> obtenerRaiz() {
        return raiz;
    }

    public T obtenerMayorPrioridad() {
        if (raiz == null) {
            return null; // El árbol está vacío
        }

        NodoPrioridad<T> nodoActual = raiz;
        while (nodoActual.getHijoDerecho() != null) {
            nodoActual = nodoActual.getHijoDerecho();
        }

        return nodoActual.getValor();
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        construirCadenaRecursiva(raiz, sb);
        return sb.toString();
    }

    private void construirCadenaRecursiva(NodoPrioridad<T> nodoActual, StringBuilder sb) {
        if (nodoActual != null) {
            // Recorrido inorden inverso
            construirCadenaRecursiva(nodoActual.getHijoDerecho(), sb);

            // Agregar el valor al StringBuilder
            sb.append(nodoActual.getValor().toString());
            sb.append("\n");

            // Recorrido inorden inverso en el subárbol izquierdo
            construirCadenaRecursiva(nodoActual.getHijoIzquierdo(), sb);
        }
    }
    public String obtenerRepresentacionArbolConDatos() {
        if (raiz == null) {
            return "Árbol vacío";
        } else {
            StringBuilder resultado = new StringBuilder();
            obtenerRepresentacionArbolConDatosRecursivoInverso(raiz, resultado);
            return resultado.toString();
        }
    }


    private void obtenerRepresentacionArbolConDatosRecursivoInverso(NodoPrioridad<T> nodo, StringBuilder resultado) {
        if (nodo != null) {
            // Llamadas recursivas primero para los hijos derecho e izquierdo
            obtenerRepresentacionArbolConDatosRecursivoInverso(nodo.getHijoDerecho(), resultado);

            // Obtener datos del paciente si el valor es un paciente
            if (nodo.getValor() instanceof Paciente) {
                Paciente paciente = (Paciente) nodo.getValor();
                resultado.append("Nombre: ").append(paciente.getNombre()).append(", ")
                        .append("Documento: ").append(paciente.getDocumento()).append(", ")
                        .append("Celular: ").append(paciente.getCelular()).append(", ")
                        .append("Correo: ").append(paciente.getCorreo()).append(", ")
                        .append("Tipo de Sangre: ").append(paciente.getTipoSangre()).append(", ")
                        .append("Edad: ").append(paciente.getEdad()).append(", ")
                        .append("Prioridad: ").append(paciente.getPrioridad()).append("\n");
            }

            // Llamada recursiva final para el hijo izquierdo
            obtenerRepresentacionArbolConDatosRecursivoInverso(nodo.getHijoIzquierdo(), resultado);
        }
    }



}


