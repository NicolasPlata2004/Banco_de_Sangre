package util;
import Clases.*;

public class Cola<T> {
    private Nodo<T> frente;
    private Nodo<T> finalCola;

    // Constructor para inicializar la cola vacía
    public Cola() {
        this.frente = null;
        this.finalCola = null;
    }

    // Método para verificar si la cola está vacía
    public boolean estaVacia() {
        return frente == null;
    }

    // Método para encolar un elemento
    public void encolar(T elemento) {
        Nodo<T> nuevoNodo = new Nodo<>(elemento);

        if (estaVacia()) {
            frente = nuevoNodo;
            finalCola = nuevoNodo;
        } else {
            finalCola.siguiente = nuevoNodo;
            finalCola = nuevoNodo;
        }
    }

    public T desencolar() {
        if (estaVacia()) {
            return null; // La cola está vacía
        }

        T elementoDesencolado = frente.valor;
        frente = frente.siguiente;

        if (frente == null) {
            finalCola = null;
        }

        return elementoDesencolado;
    }

    // Clase interna para representar los nodos de la cola
    private static class Nodo<T> {
        T valor;
        Nodo<T> siguiente;

        public Nodo(T valor) {
            this.valor = valor;
            this.siguiente = null;
        }
    }
    public T buscarPorDocumentoPaciente(String documento) {
        Nodo<T> actual = frente;

        while (actual != null) {
            // Aquí asumimos que el método getDocumento está implementado en la clase T
            if (actual.valor instanceof Paciente) {
                Paciente paciente = (Paciente) actual.valor;
                if (paciente.getDocumento().equals(documento)) {
                    return actual.valor;
                }
            }

            actual = actual.siguiente;
        }

        return null; // No se encontró el elemento con el documento especificado
    }
    public T buscarPorDocumentoDonante(String documento) {
        Nodo<T> actual = frente;

        while (actual != null) {
            // Aquí asumimos que el método getDocumento está implementado en la clase T
            if (actual.valor instanceof Donante) {
                Donante donante = (Donante) actual.valor;
                if (donante.getDocumento().equals(documento)) {
                    return actual.valor;
                }
            }

            actual = actual.siguiente;
        }

        return null; // No se encontró el elemento con el documento especificado
    }
}