package util;
import Clases.*;

public class NodoPrioridad<T> implements Comparable<NodoPrioridad<T>> {
    private int prioridad;
    private T valor;
    private NodoPrioridad<T> hijoIzquierdo;
    private NodoPrioridad<T> hijoDerecho;
    private int altura;

    public NodoPrioridad(int prioridad, T valor) {
        this.prioridad = prioridad;
        this.valor = valor;
        this.altura = 1;
    }

    public int getAltura() {
        return altura;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public T getValor() {
        return valor;
    }

    public NodoPrioridad<T> getHijoIzquierdo() {
        return hijoIzquierdo;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public void setHijoIzquierdo(NodoPrioridad<T> hijoIzquierdo) {
        this.hijoIzquierdo = hijoIzquierdo;
    }

    public NodoPrioridad<T> getHijoDerecho() {
        return hijoDerecho;
    }

    public void setHijoDerecho(NodoPrioridad<T> hijoDerecho) {
        this.hijoDerecho = hijoDerecho;
    }

    public void setValor(T valor) {
        this.valor = valor;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }
    @Override
    public int compareTo(NodoPrioridad<T> otroNodo) {
        // Lógica de comparación basada en la prioridad
        return Integer.compare(this.getPrioridad(), otroNodo.getPrioridad());
    }
}