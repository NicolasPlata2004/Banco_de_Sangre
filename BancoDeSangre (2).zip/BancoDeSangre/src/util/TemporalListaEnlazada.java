package util;

public class TemporalListaEnlazada<T> {
    private Nodo<T> cabeza;

    public void agregar(T valor) {
        Nodo<T> nuevoNodo = new Nodo<>(valor);
        nuevoNodo.siguiente = cabeza;
        cabeza = nuevoNodo;
    }

    public Nodo<T> obtenerCabeza() {
        return cabeza;
    }

    public boolean estaVacia() {
        return cabeza == null;
    }

    public void limpiar() {
        cabeza = null;
    }
    public void eliminar(T valor) {
        if (cabeza == null) {
            return; // La lista está vacía, no hay nada que eliminar.
        }

        if (cabeza.valor.equals(valor)) {
            cabeza = cabeza.siguiente;
            return;
        }

        Nodo<T> anterior = null;
        Nodo<T> actual = cabeza;

        while (actual != null && !actual.valor.equals(valor)) {
            anterior = actual;
            actual = actual.siguiente;
        }

        if (actual != null) {
            anterior.siguiente = actual.siguiente;
        }
    }



    public static class Nodo<T> {
        public T valor;
        public Nodo<T> siguiente;

        public Nodo(T valor) {
            this.valor = valor;
        }
    }
}

